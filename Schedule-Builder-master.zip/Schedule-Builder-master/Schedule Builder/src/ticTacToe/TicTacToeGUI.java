/**
 * Tic Tac Toe GUI
 * 
 * @author TJ
 * @file TicTacToeGUI.java
 * @version version 1
 */

package ticTacToe;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import net.miginfocom.swing.MigLayout;
import java.awt.SystemColor;

public class TicTacToeGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Board board;
	private JButton[] buttons;
	private JFrame frame = this;

	/**
	 * Create the frame.
	 */
	public TicTacToeGUI() {
		board = new Board();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 271, 265);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new MigLayout("", "[64.00][64.00][64.00]", "[64.00][64.00][64.00]"));
		setTitle("Tic Tac Toe");
		
		
		JButton btn0 = new JButton("");
		btn0.addActionListener(new Move(0));
		contentPane.add(btn0, "cell 0 0,alignx left,growy");
		
		JButton btn1 = new JButton("");
		btn1.addActionListener(new Move(1));
		contentPane.add(btn1, "cell 1 0,alignx left,growy");
		
		JButton btn2 = new JButton("");
		btn2.addActionListener(new Move(2));
		contentPane.add(btn2, "cell 2 0,alignx left,growy");
		
		JButton btn3 = new JButton("");
		btn3.addActionListener(new Move(3));
		contentPane.add(btn3, "cell 0 1,alignx left,growy");
		
		JButton btn4 = new JButton("");
		btn4.addActionListener(new Move(4));
		contentPane.add(btn4, "cell 1 1,alignx left,growy");
		
		JButton btn5 = new JButton("");
		btn5.addActionListener(new Move(5));
		contentPane.add(btn5, "cell 2 1,alignx left,growy");
		
		JButton btn6 = new JButton("");
		btn6.addActionListener(new Move(6));
		contentPane.add(btn6, "cell 0 2,alignx left,growy");
		
		JButton btn7 = new JButton("");
		btn7.addActionListener(new Move(7));
		contentPane.add(btn7, "cell 1 2,alignx left,growy");
		
		JButton btn8 = new JButton("");
		btn8.addActionListener(new Move(8));
		contentPane.add(btn8, "cell 2 2,alignx left,growy");
		
		buttons = new JButton[]{btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8};
	}

	
	class Move implements ActionListener{
		
		private int move;
		
		/**
		 * Constructor 
		 * 
		 * @param move is a move as an int. 
		 */
		Move(int move){
			this.move = move;
		}
		
		public void actionPerformed(ActionEvent e) {
			if(!buttons[move].getText().equals("")) 
				return;
			if(move(move)){
				win();
			}
			else{
				ComputerPlayer cPlayer = new ComputerPlayer(board);
				if(move(cPlayer.move()))
						win();
			}
		}	
			
		private boolean move(int index){
			if(board.move(index)){
				buttons[index].setText(board.getToken());
				return board.winningMove(index);
		}
		return false;
	}
		
	/**
	 * Creates an instance of WinGUI
	 */
	private void win(){
		WinGUI win = new WinGUI(board.getWinner());
		win.setLocation(frame.getX() + (frame.getWidth()/8),frame.getY()+ (frame.getHeight()/4));
		win.addWindowListener(new WindowAdapter(){
			public void windowClosed(WindowEvent e){
				if(win.getResponse()){
					board = new Board();
					for(JButton btn : buttons)
						btn.setText("");
				}
				else{
					dispose();
				}
			}
		});
		win.setVisible(true);
		}
	}
}


