/**
 *Win dialog box.
 * 
 * @author TJ
 * @file WinGUI.java
 * @version version 1
 */

package ticTacToe;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class WinGUI extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private boolean newGame = false;

	
	/**
	 * Create the WinGUI
	 * 
	 * @param winner
	 */
	public WinGUI(String winner) {
		
		setBounds(new Rectangle(212, 156));
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JLabel lblsWon = new JLabel(winner + "'s won!");
			lblsWon.setHorizontalAlignment(SwingConstants.CENTER);
			contentPanel.add(lblsWon, BorderLayout.CENTER);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("New Game");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						newGame = true;
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	/**
	 * Gets user response.
	 * 
	 * @return Returns true if the user selected a new game; otherwise, false.
	 */
	public boolean getResponse(){
		return newGame;
	}
}
