/**
 * Tic Tac Toe Board.
 * 
 * @author TJ
 * @file Board.java
 * @version version 1
 */

package ticTacToe;

public class Board {

	private String[] board;
	private boolean turn = true; 
	private String winner;
	
	/**
	 * Constructor
	 */
	public Board(){
		board = new String[9];
		for (int i = 0; i < board.length; i++)
			board[i] = " ";
	}
	
	/**
	 * Checks if the move is a winning move.
	 * 
	 * @param checkMove is the move as an integer.
	 * @return Returns true if the move is a winning move; otherwise, false.
	 */
	public boolean winningMove(int checkMove){
		
		switch (checkMove){
		case 0:
			return checkMove(0,1,2) || checkMove(0,3,6) || checkMove(0,4,8);
		case 1:
			return checkMove(0,1,2) || checkMove(1,4,7);
		case 2:
			return checkMove(0,1,2) || checkMove(2,5,8) || checkMove(2,4,6);
		case 3:
			return checkMove(0,3,6) || checkMove(3,4,5);
		case 4:
			return checkMove(0,4,8) || checkMove(1,4,7) || checkMove(2,4,6) || checkMove(3,4,5);
		case 5:
			return checkMove(3,4,5) || checkMove(2,5,8);
		case 6:
			return checkMove(0,3,6) || checkMove(2,4,6) || checkMove(6,7,8);
		case 7:
			return checkMove(1,4,7) || checkMove(6,7,8);
		case 8:
			return checkMove(0,4,8) || checkMove(2,5,8) || checkMove(6,7,8);
		default:
			return false;
		}
	}
		
	/**
	 * Checks if three spaces have the same token.
	 * 
	 * @param x is a space as an integer.
	 * @param y is a space as an integer.
	 * @param z is a space as an integer.
	 * @return Returns true if the three spaces have the same token; otherwise, false.
	 */
	public boolean checkMove(int x, int y, int z){
		if(board[x].equals(" ") || board[y].equals(" ") || board[z].equals(" ")) return false;
		if(board[x].equals(board[y]) && board[x].equals(board[z])){
			winner = board[x];
			return true;
		}
		
		return false;
	}
	
	/**
	 * Adds move to the board.
	 * 
	 * @param move is a move as an integer.
	 * @return Return true if the move is valid; otherwise, false. 
	 */
	public boolean move(int move){
		if(!board[move].equals(" ")) 
			return false;
		else{
			if(turn)
				board[move] = "X";
			else
				board[move] = "O";

			turn = !turn;
			return true;
		}
	}
	
	@Override
	public String toString(){
		return  " " + board[0] + " | " + board[1] + " | " + board[2] +
				"\n___ ___ ___ \n" +
				" " + board[3] + " | " + board[4] + " | " + board[5] +
				"\n___ ___ ___\n" +
				" " + board[6] + " | " + board[7] + " | " + board[8];
	}
	
	/**
	 * Gets token.
	 * 
	 * @return Returns token as a String.
	 */
	public String getToken(){
		if(turn) return "O";
		return "X";
	}
	
	/**
	 * Gets a cells
	 * 
	 * @param cell is the desired cell as an integer.
	 * @return Returns cell as a String.
	 */
	public String getCell(int cell){
		return board[cell];
	}
	
	/**
	 * Returns the winner.
	 * 
	 * @return 
	 */
	public String getWinner(){
		return winner;
	}
}
