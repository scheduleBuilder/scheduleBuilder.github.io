/**
 *Tic Tac Toe Computer Player
 * 
 * @author TJ
 * @file ComputerPlayer.java
 * @version version 1
 */

package ticTacToe;

import java.util.ArrayList;
import java.util.Random;

public class ComputerPlayer {
	
	
	private ArrayList<Integer> moves;
	
	/**
	 * Construct 
	 * @param board is a Tic Tac Toe Board.
	 */
	ComputerPlayer(Board board){
	
		moves = new ArrayList<>();
		
		for(int i = 0; i < 9; i++){
			if(board.getCell(i).equals(" "))
				moves.add(i);
		}
	}
	
	/**
	 * Gets a computer player move.
	 * 
	 * @return Returns a valid Computer Player Move.
	 */
	public int move(){
		if(moves.size() == 0) return 0;
		Random rand = new Random();
		int move = moves.get(rand.nextInt(moves.size()));
		return move;
	}
}
