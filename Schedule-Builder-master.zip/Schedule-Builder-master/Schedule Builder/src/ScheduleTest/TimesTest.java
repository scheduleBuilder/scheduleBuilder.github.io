package ScheduleTest;

import org.junit.Test;

import schedule.Times;
import static org.junit.Assert.*;

public class TimesTest {
	
	@Test
	public void createTimes(){
		
		Times time1 = new Times(3,6);
		Times time2 = new Times(2,4);
		Times time3 = new Times(7,8);
		
		
		assertTrue(time1.conflicts(time2));
		assertFalse(time1.conflicts(time3));
		
	}
}
