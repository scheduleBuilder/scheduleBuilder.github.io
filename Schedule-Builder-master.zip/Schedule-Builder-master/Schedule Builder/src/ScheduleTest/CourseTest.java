package ScheduleTest;

import java.util.ArrayList;

import org.junit.Test;

import schedule.Course;
import schedule.Section;
import schedule.Times;
import static org.junit.Assert.assertEquals;

public class CourseTest {

	@Test
	public void createCourse(){
		
		Section sec = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec.addClassTime(0, new Times(12, 13));
		sec.addClassTime(1, new Times(0,0));
		sec.addClassTime(2, new Times(12, 13));
		sec.addClassTime(3, new Times(0,0));
		sec.addClassTime(4, new Times(12, 13));
		
		Section sec1 = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec1.addClassTime(0, new Times(7, 8));
		sec1.addClassTime(1, new Times(9, 10));
		sec1.addClassTime(2, new Times(7, 8));
		sec1.addClassTime(3, new Times(0,0));
		sec1.addClassTime(4, new Times(7, 8));
		
		ArrayList<Section> sections = new ArrayList<>();
		
		sections.add(sec);
		sections.add(sec1);
		
		Course course = new Course("title", sections);
		
		assertEquals("title", course.getCourseTitle());
	}
}
