package ScheduleTest;

import java.util.ArrayList;

import static org.junit.Assert.*;

import org.junit.Test;

import schedule.Section;
import schedule.Times;

public class SectionTest {

	@Test
	public void createSection(){
		
		Section sec = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec.addClassTime(0, new Times(12, 13));
		sec.addClassTime(1, new Times(0,0));
		sec.addClassTime(2, new Times(12, 13));
		sec.addClassTime(3, new Times(0,0));
		sec.addClassTime(4, new Times(12, 13));
		
		Section sec1 = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec1.addClassTime(0, new Times(7, 8));
		sec1.addClassTime(1, new Times(9, 10));
		sec1.addClassTime(2, new Times(7, 8));
		sec1.addClassTime(3, new Times(0,0));
		sec1.addClassTime(4, new Times(7, 8));
		
		ArrayList<Section> secs = new ArrayList<>();
		secs.add(sec);
		secs.add(sec1);
		
		boolean conflicts = sec1.conflicts(sec);
		
		assertFalse(conflicts);
		assertEquals("crn", sec.getCrn());
		assertEquals("professor", sec.getProfessor());
		assertEquals("MWF", sec.getDays());
		assertEquals("Subject", sec.getSubject());
		assertEquals("title", sec.getTitle());		
	}
}
