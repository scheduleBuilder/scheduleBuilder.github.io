package ScheduleTest;

import static org.junit.Assert.*;

import org.junit.Test;

import schedule.CourseCatalog;

public class CourseCatalogTest {

	@Test
	public void test() {
		
		String subject = "ACCOUNTING";
		CourseCatalog catalog = new CourseCatalog("select course, title, professor from Catalog where subject = '" + subject + "'");

		Object[] str = catalog.getList();
		
		assertEquals("260 Principles of Accounting I", str[0]);
	}
}
