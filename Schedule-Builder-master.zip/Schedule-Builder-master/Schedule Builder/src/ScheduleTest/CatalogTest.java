package ScheduleTest;

import static org.junit.Assert.*;

import org.junit.Test;

import schedule.Catalog;

public class CatalogTest {

	@Test
	public void test() {
		Catalog<String> catalog = new Catalog<>("select distinct subject from Catalog");
		
		Object[] obj = catalog.getSubjectList();
		
		assertEquals("---Select Subject---", obj[0]);
	}
}
