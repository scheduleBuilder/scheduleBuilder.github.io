package ScheduleTest;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import schedule.Course;
import schedule.Schedule;
import schedule.Section;
import schedule.Times;

public class ScheduleTest {

	@Test
	public void test() {
		
		Section sec1 = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec1.addClassTime(0, new Times(12, 13));
		sec1.addClassTime(1, new Times(0,0));
		sec1.addClassTime(2, new Times(12, 13));
		sec1.addClassTime(3, new Times(0,0));
		sec1.addClassTime(4, new Times(12, 13));
		
		Section sec2 = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec2.addClassTime(0, new Times(7, 8));
		sec2.addClassTime(1, new Times(9, 10));
		sec2.addClassTime(2, new Times(7, 8));
		sec2.addClassTime(3, new Times(0,0));
		sec2.addClassTime(4, new Times(7, 8));
		
		Section sec3 = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
		
		sec3.addClassTime(0, new Times(7, 8));
		sec3.addClassTime(1, new Times(9, 10));
		sec3.addClassTime(2, new Times(7, 8));
		sec3.addClassTime(3, new Times(0,0));
		sec3.addClassTime(4, new Times(7, 8));
		
		ArrayList<Section> sections1 = new ArrayList<>();
		ArrayList<Section> sections2 = new ArrayList<>();
		
		sections1.add(sec1);
		sections2.add(sec2);
		sections2.add(sec3);
		
		Course course1 = new Course("course1", sections1);
		Course course2 = new Course("course2", sections2);
		
		Course[] courses = new Course[] {course1,course2};
		
		Schedule schedule = new Schedule(courses);
		schedule.buildSchedule();
		
		assertEquals(2, schedule.getSize());
	}

}
