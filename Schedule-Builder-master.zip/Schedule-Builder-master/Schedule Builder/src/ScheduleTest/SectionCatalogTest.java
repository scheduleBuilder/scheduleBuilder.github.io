package ScheduleTest;


import org.junit.Test;

import schedule.SelectedCatalog;
import static org.junit.Assert.assertEquals;

public class SectionCatalogTest {
	
	@Test
	public void createSectionCatalog(){
		
		SelectedCatalog sel = new SelectedCatalog("Principles of Accounting II");
		
		assertEquals("Daniel Warren Law", sel.getArrayList().get(0).getProfessor());
	}
}
