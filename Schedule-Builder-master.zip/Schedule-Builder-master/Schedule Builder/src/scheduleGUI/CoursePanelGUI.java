/**
 * JPanel to display course information
 * 
 * @author TJ
 * @file CoursePanelGUI.java
 * @version version 1
 */

package scheduleGUI;

import javax.swing.JPanel;
import schedule.Section;
import java.awt.SystemColor;
import javax.swing.ToolTipManager;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class CoursePanelGUI extends JPanel {

	//private Section section;
	
	/**
	 * Constructor
	 * 
	 * @param section is an instance of Section.
	 */
	public CoursePanelGUI(Section section) {
		setBorder(null);
		
		ToolTipManager.sharedInstance().setDismissDelay(Integer.MAX_VALUE);
		
		
		setToolTipText("<html>"
				+ "<b><font size=\"4\"> Class Information </font></b>"
				+ "<br><b>Subject:</b> "+ section.getSubject() 
				+ "<br><b> Title:</b> "+ section.getTitle() 
				+ "<br><b> Professor</b>: " + section.getProfessor() 
				+ "<br><b>Class Times:</b> " + section.getTimesDisplay() 
				+ "<br><b> CRN:</b> " + section.getCrn() 
				+ "</html>"
				);
		
		//this.section = section;
		setBackground(SystemColor.textHighlight);
		setLayout(null);
		
		JLabel lblSubject = new JLabel(section.getSubject());
		lblSubject.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubject.setBounds(6, 6, 136, 16);
		add(lblSubject);
		
		JLabel lblTitle = new JLabel(section.getTitle());
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setBounds(6, 24, 136, 16);
		add(lblTitle);
		
	}
}
