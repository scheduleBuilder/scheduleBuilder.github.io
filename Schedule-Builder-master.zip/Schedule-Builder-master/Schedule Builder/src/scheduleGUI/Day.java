/**
 * Creates Time Grid for a given day.
 * 
 * @author TJ
 * @file CoursePanelGUI.java
 * @version version 1
 */

package scheduleGUI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.border.LineBorder;
import schedule.Section;
import schedule.Times;
import javax.swing.JScrollPane;


public class Day extends JPanel {
	
	/**
	 * Default Constructor
	 */
	public Day(){
		setBorder(new LineBorder(new Color(0, 0, 0), 2));
		//setBounds(0, 0, 160, 300);
		setLayout(null);
		
		
	}
	
	/**
	 * Constructor 
	 * 
	 * @param arrayList is an ArrayList of Sections.
	 * @param day is a day as an int.
	 */
	public Day(ArrayList<Section> arrayList, int day){
		
		this();
		
		for(Section sec : arrayList){
			Times time = sec.getClassTime()[day];
			if(time.getStartTime() < 7) break;
			int y = (int) ((time.getStartTime() - 7) * 50);
			int height = (int) (((time.getEndTime() - time.getStartTime()))*50);
			
			CoursePanelGUI panel = new CoursePanelGUI(sec);
			panel.setBounds(6, y, 148, height);
			add(panel);
		}
	}

    @Override
    public void paintComponent(Graphics g)
    {	
    	for(int i = 0; i < 600; i += 25)
    		g.drawLine(1, i, 200, i);
    }
    
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				Section sec = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
				
				sec.addClassTime(0, new Times(12, 13));
				sec.addClassTime(1, new Times(0,0));
				sec.addClassTime(2, new Times(12, 13));
				sec.addClassTime(3, new Times(0,0));
				sec.addClassTime(4, new Times(12, 13));
				
				Section sec1 = new Section("crn", "professor", new Times[5], "MWF", "12am - 1pm", "title", "subject");
				
				sec1.addClassTime(0, new Times(7, 8));
				sec1.addClassTime(1, new Times(0,0));
				sec1.addClassTime(2, new Times(12, 13));
				sec1.addClassTime(3, new Times(0,0));
				sec1.addClassTime(4, new Times(12, 13));
				
				ArrayList<Section> secs = new ArrayList<>();
				secs.add(sec);
				secs.add(sec1);
				
				
				try {
					JFrame frame = new JFrame();
					Day day = new Day(secs, 0);
					day.setBounds(0, 0, 160,600);
					JScrollPane scrollPane = new JScrollPane();
					scrollPane.add(day);
					scrollPane.setBounds(0, 160, 300, 50);
					frame.getContentPane().add(scrollPane);
					
					
					frame.setBounds(0, 0, 160, 300);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
