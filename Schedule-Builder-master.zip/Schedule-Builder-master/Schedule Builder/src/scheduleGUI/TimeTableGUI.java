package scheduleGUI;


import java.awt.EventQueue;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;

import schedule.Schedule;
import schedule.Section;
import ticTacToe.TicTacToeGUI;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;


public class TimeTableGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private ScheduleBuilderGUI schedule;
	private Schedule classSchedule;
	private int scheduleIndex = 0;
	private Day monday;
	private Day tuesday;
	private Day wednesday;
	private Day thursday;
	private Day friday;
	private Day[] days;
	private TimeTableGUI frame = this;
	private JButton btnNext;
	private JButton btnPrevious;
	private JLabel lblOf;
	

	/**
	 * Create the frame.
	 */
	public TimeTableGUI() {
		
		schedule = new ScheduleBuilderGUI();
		schedule.addWindowListener(new WindowAdapter(){
			public void windowClosed(WindowEvent e){
				Object[] courses = schedule.getSelectedModel();
				classSchedule = new Schedule(courses);
				classSchedule.buildSchedule();
				ArrayList<ArrayList<Section>> classes = classSchedule.getAllSchedules();
				if(classes.size() < 1){
					createSchedule(new ArrayList<Section>());
					btnNext.setEnabled(false);
					btnPrevious.setEnabled(false);
					return;
				}
				createSchedule(classSchedule.getAllSchedules().get(0));
				scheduleIndex = 0;
				lblOf.setText((scheduleIndex+1) + " of " + classSchedule.getSize());
				
				if(classSchedule.getSize() == 1)
					btnNext.setEnabled(false);
				else
					btnNext.setEnabled(true);
			}
		});
		
		setTitle("Schedule Builder");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 715);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		monday = new Day();
		monday.setBounds(54, 50, 160, 600);
		contentPane.add(monday);
		
		tuesday = new Day();
		tuesday.setBounds(213, 50, 160, 600);
		contentPane.add(tuesday);
		
		wednesday = new Day();
		wednesday.setBounds(373, 50, 160, 600);
		contentPane.add(wednesday);
		
		thursday = new Day();
		thursday.setBounds(533, 50, 160, 600);
		contentPane.add(thursday);
		
		friday = new Day();
		friday.setBounds(693, 50, 160, 600);
		contentPane.add(friday);
		
		days = new Day[]{monday, tuesday, wednesday, thursday, friday};
		
		JLabel lblMonday = new JLabel("Monday");
		lblMonday.setHorizontalAlignment(SwingConstants.CENTER);
		lblMonday.setBounds(91, 30, 79, 21);
		contentPane.add(lblMonday);
		
		JLabel lblTuesday = new JLabel("Tuesday");
		lblTuesday.setHorizontalAlignment(SwingConstants.CENTER);
		lblTuesday.setBounds(253, 30, 79, 21);
		contentPane.add(lblTuesday);
		
		JLabel lblWednesay = new JLabel("Wednesday");
		lblWednesay.setHorizontalAlignment(SwingConstants.CENTER);
		lblWednesay.setBounds(416, 30, 79, 21);
		contentPane.add(lblWednesay);
		
		JLabel lblThursday = new JLabel("Thursday");
		lblThursday.setHorizontalAlignment(SwingConstants.CENTER);
		lblThursday.setBounds(575, 30, 79, 21);
		contentPane.add(lblThursday);
		
		JLabel lblFriday = new JLabel("Friday");
		lblFriday.setHorizontalAlignment(SwingConstants.CENTER);
		lblFriday.setBounds(733, 30, 79, 21);
		contentPane.add(lblFriday);
		
		JButton btnProperties = new JButton("Edit Classes");
		btnProperties.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schedule.setVisible(true);
			}
		});
		btnProperties.setBounds(760, 658, 117, 29);
		contentPane.add(btnProperties);
		
		JButton btnTicTacToe = new JButton("Tic Tac Toe");
		
		
		btnTicTacToe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TicTacToeGUI ttt = new TicTacToeGUI();
				ttt.setLocation(new Point(frame.getWidth()/2,frame.getHeight()/2));
				ttt.setVisible(true);
			}
		});
		btnTicTacToe.setBounds(631, 658, 117, 29);
		contentPane.add(btnTicTacToe);
		
		JLabel lbl7 = new JLabel("7 am");
		lbl7.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl7.setBounds(6, 46, 41, 16);
		contentPane.add(lbl7);
		
		JLabel lbl8 = new JLabel("8 am");
		lbl8.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl8.setBounds(6, 96, 41, 16);
		contentPane.add(lbl8);
		
		JLabel lbl9 = new JLabel("9 am");
		lbl9.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl9.setBounds(6, 146, 41, 16);
		contentPane.add(lbl9);
		
		JLabel lbl10 = new JLabel("10 am");
		lbl10.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl10.setBounds(6, 196, 41, 16);
		contentPane.add(lbl10);
		
		JLabel lbl11 = new JLabel("11 am");
		lbl11.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl11.setBounds(6, 246, 41, 16);
		contentPane.add(lbl11);
		
		JLabel lbl12 = new JLabel("12 pm");
		lbl12.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl12.setBounds(6, 296, 41, 16);
		contentPane.add(lbl12);
		
		JLabel lbl1 = new JLabel("1 pm");
		lbl1.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl1.setBounds(6, 346, 41, 16);
		contentPane.add(lbl1);
		
		JLabel lbl2 = new JLabel("2 pm");
		lbl2.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl2.setBounds(6, 396, 41, 16);
		contentPane.add(lbl2);
		
		JLabel lbl3 = new JLabel("3 pm");
		lbl3.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl3.setBounds(6, 446, 41, 16);
		contentPane.add(lbl3);
		
		JLabel lbl4 = new JLabel("4 pm");
		lbl4.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl4.setBounds(6, 496, 41, 16);
		contentPane.add(lbl4);
		
		JLabel lbl5 = new JLabel("5 pm");
		lbl5.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl5.setBounds(6, 546, 41, 16);
		contentPane.add(lbl5);
		
		JLabel lbl6 = new JLabel("6 pm");
		lbl6.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl6.setBounds(6, 596, 41, 16);
		contentPane.add(lbl6);
		
		JLabel lblPm = new JLabel("7 pm");
		lblPm.setHorizontalAlignment(SwingConstants.TRAILING);
		lblPm.setBounds(6, 641, 41, 16);
		contentPane.add(lblPm);
		
		btnPrevious = new JButton("Previous");
		btnPrevious.setEnabled(false);
		btnPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(scheduleIndex == 0) return;
				
				scheduleIndex--;
				
				createSchedule(classSchedule.getAllSchedules().get(scheduleIndex));
				btnNext.setEnabled(true);
				lblOf.setText((scheduleIndex+1) + " of " + classSchedule.getSize());
				if(scheduleIndex == 0)
					btnPrevious.setEnabled(false);
			}
		});
		btnPrevious.setBounds(53, 658, 117, 29);
		contentPane.add(btnPrevious);
		
		btnNext = new JButton("Next");
		btnNext.setEnabled(false);
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(scheduleIndex == classSchedule.getSize() -1) return;
				
				scheduleIndex++;
				
				createSchedule(classSchedule.getAllSchedules().get(scheduleIndex));
				btnPrevious.setEnabled(true);
				lblOf.setText((scheduleIndex+1) + " of " + classSchedule.getSize());
				if(scheduleIndex == classSchedule.getSize() -1)
					btnNext.setEnabled(false);
			}
		});
		btnNext.setBounds(167, 658, 117, 29);
		contentPane.add(btnNext);
		
		lblOf = new JLabel("0 of 0");
		lblOf.setHorizontalAlignment(SwingConstants.CENTER);
		lblOf.setBounds(296, 663, 99, 16);
		contentPane.add(lblOf);
	}
	
	private void createSchedule(ArrayList<Section> classes){
		
		SplitSchedule split = new SplitSchedule(classes);
		
		for(int i = 0; i < 5; i++){
			
			Rectangle bounds = days[i].getBounds();
			contentPane.remove(days[i]);
	
			
			Day newDay = new Day(split.getDay(i), i);
			newDay.setBounds(bounds);
			days[i] = newDay;
			contentPane.add(days[i]);
			contentPane.repaint();
		}
	}
	
	private class SplitSchedule{
		
		private ArrayList<Section> monday = new ArrayList<>();
		private ArrayList<Section> tuesday = new ArrayList<>();
		private ArrayList<Section> wednesday = new ArrayList<>();
		private ArrayList<Section> thursday = new ArrayList<>();
		private ArrayList<Section> friday = new ArrayList<>();
		
		public SplitSchedule(ArrayList<Section> schedule){
			for (Section sec : schedule){
				String str =  sec.getDays();
				
				if(str.contains("M"))
					monday.add(sec);
				if(str.contains("T"))
					tuesday.add(sec);
				if(str.contains("W"))
					wednesday.add(sec);
				if(str.contains("R"))
					thursday.add(sec);
				if(str.contains("F"))
					friday.add(sec);
			}
		}
		
		public ArrayList<Section> getDay(int day){
			switch (day){
			case 0:
				return monday;
			case 1:
				return tuesday;
			case 2: 
				return wednesday;
			case 3:
				return thursday;
			case 4:
				return friday;
			default:
				return null;
			}
		}
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TimeTableGUI frame = new TimeTableGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}

