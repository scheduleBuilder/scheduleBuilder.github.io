package scheduleGUI;

import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ListCellRenderer;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ListSelectionModel;
import schedule.Catalog;
import schedule.Course;
import schedule.Section;
import schedule.CourseCatalog;
import schedule.SelectedCatalog;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JScrollPane;


public class ScheduleBuilderGUI extends JFrame{

	
	private Catalog<String> catalog;
	private JList<Course> selected;
	private JList<Section> professors;
	private JList<Section> times;
	private DefaultListModel<String> model = new DefaultListModel<>();
	private DefaultListModel<Course> selectedModel = new DefaultListModel<>();


	private DefaultListModel<Section> classesModel = new DefaultListModel<>();

	/**
	 * Default Constructor
	 */
	public ScheduleBuilderGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		setTitle("Course Selection");
		setResizable(false);
		setVisible(false);
		setBounds(100, 200, 840, 334);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		getContentPane().setLayout(null);
		

		catalog = new Catalog<>("select distinct subject from Catalog");

		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.clear();
				fillClass(comboBox.getSelectedItem());
			}
		});
		
		comboBox.setModel(new DefaultComboBoxModel(catalog.getSubjectList()));
		comboBox.setToolTipText("Select Subject");
		comboBox.setBounds(16, 0, 200, 50);
		getContentPane().add(comboBox);
		
		/////////
		professors = new JList<>(classesModel);
		JScrollPane professorScrollPane = new JScrollPane(professors);
		professorScrollPane.setBounds(427, 72, 192, 194);
		
		
		professors.setCellRenderer(new TeacherCheckboxListRenderer());
		professors.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	 
	      // Add a mouse listener to handle changing selection
	 
		professors.addMouseListener(new MouseAdapter() {
	         public void mouseClicked(MouseEvent event) {
	            JList<Section> list = (JList<Section>) event.getSource();
	 
	            int index = list.locationToIndex(event.getPoint());
	            Section item = (Section) list.getModel().getElementAt(index);

	            item.setSelectedProfessor(!item.isSelectedProfessor());

	            list.repaint(list.getCellBounds(index, index));
	            professors.repaint();
	            times.repaint();
	         }
	      });
		
		getContentPane().add(professorScrollPane);
		

		JList<String> subject = new JList<String>(model);
		JScrollPane scrollPane = new JScrollPane(subject);
		scrollPane.setBounds(16, 72, 192, 194);
		getContentPane().add(scrollPane);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(subject.isSelectionEmpty())return;
				
				
				String str = model.getElementAt(subject.getSelectedIndex());
				
				for(int i = 0; i < selectedModel.size(); i++)
					if(selectedModel.getElementAt(i).getCourseTitle().equals(str)) return;
				
				SelectedCatalog sec = new SelectedCatalog(str.substring(4));
		
				selectedModel.addElement( new Course(str, sec.getArrayList()));
				selected.setSelectedIndex(selectedModel.getSize()-1);
			}
		});
		btnAdd.setBounds(44, 269, 117, 29);
		getContentPane().add(btnAdd);
		
		selected = new JList<>(selectedModel);
		JScrollPane selectedScrollPane = new JScrollPane(selected);
		selectedScrollPane.setBounds(223, 72, 192, 194);
		
		selected.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if(selected.isSelectionEmpty()) return;
				classesModel.clear();
				
				Course cur = selected.getSelectedValue();
				
				
				for (Section sec : cur.getSections()){
					if(!classesModel.contains(sec.getProfessor())) 
						classesModel.addElement(sec);
				}		
			}
		});
		selected.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(selected.isSelectionEmpty()) return;
				classesModel.clear();
				
				Course cur = selected.getSelectedValue();
				
				for (Section sec : cur.getSections())
					if(!classesModel.contains(sec.getProfessor()))
						classesModel.addElement(sec);
					
						
			}
		});
		
		getContentPane().add(selectedScrollPane);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(selected.isSelectionEmpty())return;
				classesModel.clear();
				selectedModel.remove(selected.getSelectedIndex());
				selected.setSelectedIndex(0);
			}
		});
		btnRemove.setBounds(252, 269, 117, 29);
		getContentPane().add(btnRemove);
		
		JLabel lblAddCourse = new JLabel("Add Course");
		lblAddCourse.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddCourse.setBounds(70, 50, 79, 16);
		getContentPane().add(lblAddCourse);
		
		JLabel lblSelectedCourse = new JLabel("Selected Course");
		lblSelectedCourse.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectedCourse.setBounds(252, 50, 117, 16);
		getContentPane().add(lblSelectedCourse);
		
		JLabel lblProfessors = new JLabel("Professors");
		lblProfessors.setHorizontalAlignment(SwingConstants.CENTER);
		lblProfessors.setBounds(485, 50, 79, 16);
		getContentPane().add(lblProfessors);
		
		/////////////////
		times = new JList<Section>(classesModel);
		JScrollPane timesScrollPane = new JScrollPane(times);
		timesScrollPane.setBounds(631, 72, 192, 194);
		
		times.setCellRenderer(new TimesCheckboxListRenderer());
		times.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	 
	      // Add a mouse listener to handle changing selection
	 
		times.addMouseListener(new MouseAdapter() {
	         public void mouseClicked(MouseEvent event) {
	            JList<Section> list = (JList<Section>) event.getSource();
	 
	            int index = list.locationToIndex(event.getPoint());
	            Section item = (Section) list.getModel().getElementAt(index);

	            item.setSelectedTime(!item.isSelectedTime());

	            professors.repaint();
	            times.repaint();
	         }
	      });
		times.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		
		getContentPane().add(timesScrollPane);
		
		JLabel lblTimes = new JLabel("Class Times");
		lblTimes.setHorizontalAlignment(SwingConstants.CENTER);
		lblTimes.setBounds(688, 50, 79, 16);
		getContentPane().add(lblTimes);
		
		JButton btnAddSchedule = new JButton("Add To Schedule");
		btnAddSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnAddSchedule.setBounds(671, 269, 152, 29);
		getContentPane().add(btnAddSchedule);
		
		
	}
	
	/**
	 * @return the selectedModel
	 */
	public Object[] getSelectedModel() {
		return selectedModel.toArray();
	}
	
	public void fillClass(Object subject){
			
		CourseCatalog catalog = new CourseCatalog("select course, title, professor from Catalog where subject = '" + subject + "'");

		Object[] str = catalog.getList();
		
		
		for(Object obj : str){
			if(!model.contains(obj))
				model.addElement((String) obj);
		}
	}
}


/**
 * Checkbox Renderer
 * @author TJ
 *
 */
class TeacherCheckboxListRenderer extends JCheckBox implements ListCellRenderer<Section> {

	@Override
	public Component getListCellRendererComponent(JList<? extends Section> list, Section value, int index, boolean isSelected, boolean cellHasFocus) {
		setEnabled(list.isEnabled());
		setSelected(value.isSelectedProfessor());
		setFont(list.getFont());
		setBackground(list.getBackground());
		setForeground(list.getForeground());
		setText(value.getProfessor());
		return this;
	}
}

/**
 * Checkbox Renderer
 * @author TJ
 *
 */
class TimesCheckboxListRenderer extends JCheckBox implements ListCellRenderer<Section> {

	@Override
	public Component getListCellRendererComponent(JList<? extends Section> list, Section value, int index, boolean isSelected, boolean cellHasFocus) {
		setEnabled(list.isEnabled());
		setSelected(value.isSelectedTime());
		setFont(list.getFont());
		setBackground(list.getBackground());
		setForeground(list.getForeground());
		setText(value.getTimesDisplay());
		return this;
	}	
}
