/**
 * Times hold the starts and end times for a given
 * class period. It can also check if too class periods 
 * are conflicting. 
 * 
 * @author TJ
 * @file Times.java
 * @version version 1
 */

package schedule;

public class Times {
	 
	private float startTime;
	private float endTime;
	
	/**
	 * Constructor
	 * 
	 * @param startTime startTime is the time the class period begins
	 * @param endTime startTime is the time the class period finishes
	 */
	public Times(float startTime, float endTime){
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	/**
	 * Checks if two Times conflict with each other.
	 * 
	 * @param time contains class time interval
	 * @return true if times conflict; otherwise, false.
	 */
	public boolean conflicts(Times time){
		if(this.startTime == 0.0 || time.startTime == 0.0) return false;
		return !(this.endTime <= time.startTime || time.endTime <= this.startTime);
	}
	
	@Override
	public String toString(){
		return startTime + " to " + endTime;
	}
	
	/**
	 * @return the startTime
	 */
	public float getStartTime() {
		return startTime;
	}

	/**
	 * @return the endTime
	 */
	public float getEndTime() {
		return endTime;
	}

	public static void main(String[] args){
		
		Times time1 = new Times(5,6);
		Times time2 = new Times(2,5);
	
		if(time1.conflicts(time2))
			System.out.println("Conflicts");
	}
}
