/**
 * Connects to the MySQL Database to pull course information from the Catalog table.
 * Extends Catalog.
 * 
 * @author TJ
 * @file CourseCatalog.java
 * @version version 1
 */

package schedule;

import java.sql.SQLException;

public class CourseCatalog extends Catalog<String> {
	
	private Course course;
	
	/**
	 * Constructor
	 * 
	 * @param statement
	 */
	public CourseCatalog(String statement){
		super(statement);
	}
	
	/**
	 * Gets Items.
	 * 
	 * @returns Returns item from the Result Set as a String
	 */
	public String getItems() throws SQLException{
		return getRs().getString("course") + " " + getRs().getString("title") ;
	}
}
