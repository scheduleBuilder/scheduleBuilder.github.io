/**
 * Connects to the MySQL Database to pull course information from the Catalog table.
 * 
 * @author TJ
 * @file Catalog.java
 * @version version 1
 */

package schedule;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;

public class Catalog<type> {
	
	private static String dbUrl = "jdbc:mysql://localhost:3306/Catalog?autoReconnect=true&useSSL=false";
	private static String user = "cpsc224";		
	private static String pass = "password";
	private ArrayList<type> list;
	
	private Connection conn;
	private Statement stmt;
	private ResultSet rs;

	
	/**
	 * Constructor
	 */
	public Catalog(){
		this.conn = null;
		this.stmt = null;
		this.rs = null;
	}
	
	/**
	 * Constructor
	 * 
	 * @param statement is the Statement to be executed as a String.
	 */
	public Catalog(String statement){
		this();
		try {
			executeStmt(statement);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Executes Statement
	 * 
	 * @param statement is the Statement to be executed as a String.
	 * @throws SQLException Throws SQLExecute 
	 */
	public void executeStmt(String statement) throws SQLException{
		
		try{
			
			conn = DriverManager.getConnection(dbUrl, user, pass);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(statement);
			
			list = new ArrayList<>();
			fillList();
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(rs != null)
				rs.close();
			
			if(stmt != null)
				stmt.close();
			
			if(conn != null)
				conn.close();
		}
	}
	
	/**
	 * Gets List.
	 * 
	 * @return Returns a List of Objects.
	 */
	public Object[] getList() {
		Object[] obj = list.toArray();
		Arrays.sort(obj);
		return obj;
	}
	
	/**
	 * Gets Subject List
	 * 
	 * @return Returns of list of Subjects as String.
	 */
	public Object[] getSubjectList() {
		list.add(0, (type) "---Select Subject---");
		Object[] obj = list.toArray();
		Arrays.sort(obj);
		return obj;
	}
	
	/**
	 * Gets Array List.
	 * 
	 * @return 
	 */
	public ArrayList<type> getArrayList(){
		return list;
	}

	/**
	 * Gets Item.
	 * 
	 * @return Returns item from Result set as an Instance of Type.
	 * @throws SQLException
	 */
	public type getItems() throws SQLException{
		return (type) rs.getString("subject");
	}
	
	/**
	 * Gets Result Set.
	 * 
	 * @return Returns the Result Set.
	 */
	public ResultSet getRs() {
		return rs;
	}
	
	/**
	 * Fills the list with items from the result set.
	 * 
	 * @throws SQLException
	 */
	protected void fillList() throws SQLException{
		while(rs.next())
			list.add(getItems());
	}
	
	public static void main(String[] args){
		Catalog<String> mySQL = new Catalog<>();
		try {
			mySQL.executeStmt("select distinct subject, title from Catalog");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		for(Object str : mySQL.getList())
			System.out.println(str);
	}
}
