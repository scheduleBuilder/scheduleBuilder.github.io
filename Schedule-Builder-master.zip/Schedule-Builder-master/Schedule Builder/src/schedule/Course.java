/**
 * Courses holds information about the course including all possible sections.
 * 
 * @author TJ
 * @file Course.java
 * @version version 1
 */

package schedule;

import java.util.ArrayList;

public class Course{
	
	
	private String courseTitle;
	private Section[] sections;
	
	/**
	 * Constructor 
	 * @param sections is an ArrayList<Sections>.
	 */
	public Course(ArrayList<Section> sections){
		this.sections = new Section[sections.size()];
		
		for(int i = 0; i < sections.size(); i++)
			this.sections[i] = sections.get(i);
	}
	
	/**
	 * Constructor
	 * 
	 * @param courseTitle is the Course title as a String.
	 * @param sections is an ArrayList<Sections>.
	 */
	public Course(String courseTitle, ArrayList<Section> sections){
		this(sections);
		this.courseTitle = courseTitle;
		
	}
	
	/**
	 * Gets the Course title.
	 * 
	 * @return Returns the Course title as a String.
	 */
	public String getCourseTitle() {
		return courseTitle;
	}

	
	/**
	 * Gets the Course sections.
	 * 
	 * @return Returns all the sections in array.
	 */
	public Section[] getSections() {
		return sections;
	}
	
	@Override
	public String toString(){
		return courseTitle;
	}
}
