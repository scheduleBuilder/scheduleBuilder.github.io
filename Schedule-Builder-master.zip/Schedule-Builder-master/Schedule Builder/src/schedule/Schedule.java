/**
 * Schedule develops a possible course schedule from the
 * give course and sections
 * 
 * @author TJ
 * @file Schedule.java
 * @version version 1
 */

package schedule;

import java.util.ArrayList;
import java.util.ListIterator;

public class Schedule {

	private ArrayList<Section> schedule;
	private ArrayList<ArrayList<Section>> allSchedules = new ArrayList<>();
	private Object[] courses;
	private int size;
	
	/**
	 * Constructor
	 * 
	 * @param courses is an Array of Courses.
	 */
	public Schedule(Object[] courses){
		this.courses = courses;
		this.schedule = new ArrayList<>();
	}
	

	/**
	 * Builds all possible schedules.
	 */
	public void buildSchedule(){
		if(courses.length == 0) return;
		
		
		
		for(Section section : ((Course) courses[0]).getSections()){
			ArrayList<Section> sched = new ArrayList<>();
			if(section.isSelected()){
				sched.add(section);
				allSchedules.add(sched);
			}
		}
		
		
		for(int i = 1; i < courses.length; i++){
			ListIterator<ArrayList<Section>> iter = allSchedules.listIterator();
			ArrayList<ArrayList<Section>> temp = new ArrayList<>();
			
			while(iter.hasNext()){
				
				ArrayList<Section> sched = iter.next();
				for(Section section : ((Course) courses[i]).getSections()){
					
					if(section.isSelected() && !conflicts(sched, section, sched.size())){
						ArrayList<Section> copy = (ArrayList<Section>) sched.clone();
						copy.add(section);
						temp.add(copy);
						System.out.println("true");
					}
				}
				allSchedules = temp;
			}
		}
		size = allSchedules.size();
	}
	
	private ArrayList<Section> copy(ArrayList<Section> original){
		ArrayList<Section> copy = new ArrayList<>();
		for(Section sec : original)
			copy.add(sec);
		return copy;
	}
	
	
	/**
	 * Checks if a Sections conflict with the schedule.
	 * 
	 * @param section is a possible class section
	 * @return true if section conflicts; otherwise, false.
	 */
	public boolean conflicts(Section section, int index){	
		
		if(index == 0)
			return false;
		else if(section.conflicts(schedule.get(index-1)))
			return true;
		else 
			return conflicts(section, --index);
	}
	
	/**
	 * Checks if a Sections conflict with the schedule.
	 * 
	 * @param section is a possible class section
	 * @return true if section conflicts; otherwise, false.
	 */
	public boolean conflicts(ArrayList<Section> sched, Section section, int index){	
		
		if(index == 0)
			return false;
		else if(section.conflicts(sched.get(index-1)))
			return true;
		else 
			return conflicts(sched, section, --index);
	}
	
	@Override
	public String toString(){
		String str = new String("");
		
		for(Section sec : schedule)
			str += sec.getCrn() + "\n";
		
		return str;
	}
	
	/**
	 * @return the allSchedules
	 */
	public ArrayList<ArrayList<Section>> getAllSchedules() {
		return allSchedules;
	}
	

	/**
	 * Gets the number of schedules.
	 * 
	 * @return the size of allSchedules as an int.
	 */
	public int getSize() {
		return size;
	}

	public static void main(String[] args){
		
//		
//		Section sec1 = new Section("123");
//		Section sec2 = new Section("456");
//		Section sec3 = new Section("789");
//		
//		sec1.addClassTime(0, new Times(1,4));
//		sec1.addClassTime(2, new Times(1,4));
//		sec1.addClassTime(4, new Times(1,4));
//		
//		sec2.addClassTime(0, new Times(3,4));
//		sec2.addClassTime(2, new Times(3,4));
//		sec2.addClassTime(4, new Times(3,4));
//		
//		sec3.addClassTime(1, new Times(3,4));
//		sec3.addClassTime(3, new Times(3,4));
//		
//		
//		ArrayList<Section> class1 = new ArrayList<>();
//		ArrayList<Section> class2 = new ArrayList<>();
//		
//		class1.add(sec1);
//		class1.add(sec2);
//		class2.add(sec3);
//		
//		
//		
//		Course[] course = new Course[] {new Course("Math", class1), new Course("Stats", class2)};
//		
//		
//		
//		Schedule schedule = new Schedule(course);
//		schedule.buildSchedule();
//		System.out.println(schedule.toString());
	}
}
