/**
 * Section contains the course registration number and 
 * all the class times during the week.
 * 
 * @author TJ
 * @file Section.java
 * @version version 1
 */

package schedule;

public class Section {

	private String crn;
	private String subject;
	private String title;
	private String professor;
	private Times[] classTime;
	private boolean isSelectedProfessor = true;
	private boolean isSelectedTime = true;
	private String days;
	private String times;
	

	/**
	 * Constructor
	 */
	public Section(String crn, String professor, Times[] time, String days, String times, String title, String subject){
		this.crn = crn;
		this.subject = formatString(subject);
		this.professor = professor;
		classTime = time;
		this.days = days;
		this.times = times;
		this.title = title;
	}
	

	/**
	 * Adds class period to the array of class times
	 * 
	 * @param index index corresponds to a weekday - (0, Mon), (1, Tue), ...
	 * @param time time is an instance of Times
	 */
	public void addClassTime(int index, Times time){
		classTime[index] = time;
	}
	
	/**
	 * Checks if two Sections conflict with each other.
	 * 
	 * @param section is the class section
	 * @return true if sections conflict; otherwise, false.
	 */
	public boolean conflicts(Section section){
		
		for(int i = 0; i < 5; i++){
			if(this.classTime[i] == null || section.classTime[i] == null)
				break;
			else if(this.classTime[i].conflicts(section.classTime[i]))
				return true;
		}
		return false;
	}
	
	/**
	 * Gets the course registration number
	 * 
	 * @return crn the course registration number
	 */
	public String getCrn()
	{
		return crn;
	}
	
	/**
	 * Gets the section professor.
	 * 
	 * @return Returns professor as a String.
	 */
	public String getProfessor(){
		return professor;
	}
	
	@Override
	public String toString(){
		
		String str = new String();
		
		for (Times time : classTime)
			str += time.toString() + "\n";
			
		return str;
	}
	
	/**
	 * Gets Section Times.
	 * 
	 * @return Returns Section Times as an array of Times.
	 */
	public Times[] getClassTime() {
		return classTime;
	}

	/**
	 * Checks if the professor is selected.
	 * 
	 * @return Returns true if the professor is selected; otherwise, false.
	 */
	public boolean isSelectedProfessor() {
		return isSelectedProfessor;
	}

	/**
	 * Sets the isSelectedValue to either true or false.
	 * 
	 * @param isSelectedProfessor is a boolean value.
	 */
	public void setSelectedProfessor(boolean isSelectedProfessor) {
		this.isSelectedProfessor = isSelectedProfessor;
	}

	/**
	 * Checks if the Section Time is selected.
	 * 
	 * @return Returns true if the Section Time is selected; otherwise, false.
	 */
	public boolean isSelectedTime() {
		return isSelectedTime;
	}

	/**
	 * Sets the isSelectedTime to either true or false.
	 * 
	 * @param isSelectedTime is a boolean value.
	 */
	public void setSelectedTime(boolean isSelectedTime) {
		this.isSelectedTime = isSelectedTime;
	}

	/**
	 * Gets the Section Display Time.
	 * 
	 * @return Returns the Section Display Time as a String.
	 */
	public String getTimesDisplay() {
		return days + " " + times; 
	}
	
	/**
	 * Gets the Section days.
	 * 
	 * @return Returns days as a String.
	 */
	public String getDays() {
		return days;
	}
	
	
	/**
	 * Get the Section title.
	 * 
	 * @return Returns the Class title as a String.
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Gets the Section subject.
	 * 
	 * @return Returns the Section Subject as a String.
	 */
	public String getSubject() {
		return subject;
	}
	
	/**
	 * Checks if the Section isSelected
	 * 
	 * @return Returns true if the Section is selected; otherwise, false.
	 */
	public boolean isSelected(){
		return isSelectedProfessor && isSelectedTime;
	}
	
	/**
	 * Standardizes the capitalization of a String.
	 * 
	 * @param original is a String.
	 * @return Returns a new String.
	 */
	public String formatString(String original){
		char[] str1 = original.toLowerCase().toCharArray();
		StringBuilder str = new StringBuilder();
		
		for(int i = 0; i < str1.length; i++){
			if(i == 0)
				str.append(Character.toUpperCase(str1[0]));
			else if(str1[i-1] == 32)
				str.append(Character.toUpperCase(str1[i]));
			else
				str.append(str1[i]);
		}
		return str.toString();
	}

	public static void main(String[] args){
		
//		//test
//		Section sec1 = new Section();
//		Section sec2 = new Section();
//		Section sec3 = new Section();
//		
//		
//		sec1.addClassTime(0, new Times(1,2));
//		sec1.addClassTime(2, new Times(1,2));
//		sec1.addClassTime(4, new Times(1,2));
//		
//		sec2.addClassTime(0, new Times(3,5));
//		
//		sec3.addClassTime(0, new Times(2,5));
//		
//		
//		if(sec1.conflicts(sec2) || sec1.conflicts(sec3))
//			System.out.println("Conflicts");
	}
	
}
