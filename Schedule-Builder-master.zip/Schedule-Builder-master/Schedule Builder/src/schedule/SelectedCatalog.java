/**
 * Connects to the MySQL Database to pull course information from the Catalog table and builds sections.
 * Extends Catalog.
 * 
 * @author TJ
 * @file SelectedCatalog.java
 * @version version 1
 */

package schedule;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectedCatalog extends Catalog<Section>{

	/**
	 * Constructor 
	 * 
	 * @param statement is the Statement to be executed
	 */
	public SelectedCatalog(String statement){
	
		super("select subject, course, title, crn, professor, days, times, mon_start, mon_end, tue_start, tue_end, wed_start, wed_end, thur_start, thur_end, fri_start, fri_end from Catalog where title = '"+ statement +"'");
	}
	
	/**
	 * Gets Items from MySQL Database
	 * 
	 * @returns Returns items as Sections.
	 */
	public Section getItems() throws SQLException{
		
		ResultSet rs = getRs();
		
		Section sec = new Section(rs.getString("crn"), rs.getString("professor"), new Times[5], rs.getString("days"), rs.getString("times"), rs.getString("title"), rs.getString("subject"));
		
		sec.addClassTime(0, new Times(rs.getFloat("mon_start"),rs.getFloat("mon_end")));
		sec.addClassTime(1, new Times(rs.getFloat("tue_start"),rs.getFloat("tue_end")));
		sec.addClassTime(2, new Times(rs.getFloat("wed_start"),rs.getFloat("wed_end")));
		sec.addClassTime(3, new Times(rs.getFloat("thur_start"),rs.getFloat("thur_end")));
		sec.addClassTime(4, new Times(rs.getFloat("fri_start"),rs.getFloat("fri_end")));
		
		return sec;
	}

	
	public static void main(String[] args) {
		SelectedCatalog sel = new SelectedCatalog("'Principles of Accounting II'");
		
		for(Section cur : sel.getArrayList())
			System.out.println(cur.getProfessor());
	}
}
